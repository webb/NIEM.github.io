This NIEM v3.0 IEPD builds off the Super Hero Based IEPD demonstrates how to implement the association concept in NIEM.  

The definition for "Association" is provided in the Naming and Design Rules (NDR) specification in Section 10.3. 

The definition for "Association Type" is provided in the NDR in Section 10.3.  

Additional rules for "Association Type" are found in:
   - Section 5.6.5.2, 
   - Section 5.6.5.3, 
   - Section 5.6.5.4, 
   - Section 5.6.5.4, 
   - Section 5.6.5.5, 
   - Section 5.6.5.6, 
   - Section 5.6.5.6, 
   - Section 5.6.5.7, 
   - Section 5.6.5.8, 
   - Section 5.6.5.8, 
   - Section 5.6.5.9, 
   - Section 5.6.5.10, 
   - Section 5.6.5.10, 
   - Section 5.6.5.11, 
   - Section 5.6.6, 
   - Section 5.6.6, 
   - Section 5.6.7, 
   - Section 10.3.2, 
   - Section 10.4, 
   - Section 10.4, 
   - Section 10.4.1

Quicklinks to these references are provided in Appendix G. General Index in the NDR at URL:  http://reference.niem.gov/niem/specification/naming-and-design-rules/3.0/NIEM-NDR-3.0-2014-07-31.html#appendix_G. 
