This NIEM v3.0 IEPD builds off the Super Hero Based IEPD demonstrates how to implement the "Local Terminology" concept in NIEM.  

The definition for "Local Term" is provided in the Naming and Design Rules (NDR) specification in Section 10.8.2.1. 

The definition for "Local Terminology Appinfo Namespace" is provided in the NDR in Section 10.8.2.1.  

Quicklinks to these references are provided in Appendix G. General Index in the NDR at URL:  http://reference.niem.gov/niem/specification/naming-and-design-rules/3.0/NIEM-NDR-3.0-2014-07-31.html#appendix_G. 
