This NIEM v3.0 IEPD builds off the Super Hero Based IEPD demonstrates how to implement the "Reference" concept in NIEM.  

The definition for "Reference Element" is provided in the Naming and Design Rules (NDR) specification in Section 12.2. 

Quicklinks to these references are provided in Appendix G. General Index in the NDR at URL:  http://reference.niem.gov/niem/specification/naming-and-design-rules/3.0/NIEM-NDR-3.0-2014-07-31.html#appendix_G. 
