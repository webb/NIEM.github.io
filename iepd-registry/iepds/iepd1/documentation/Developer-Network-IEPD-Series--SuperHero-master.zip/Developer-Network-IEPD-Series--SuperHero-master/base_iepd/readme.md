This IEPD show how to create a basic extension schema file with one element that reuses a NIEM Core type.  The context of this IEPD is based on Super Hero's.
