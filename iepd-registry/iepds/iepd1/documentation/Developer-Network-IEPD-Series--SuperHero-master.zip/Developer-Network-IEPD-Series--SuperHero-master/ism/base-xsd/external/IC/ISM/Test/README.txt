Open testConfig.xml in a XSLT-capabable browser, such as Internet Explorer, and 
it will use the ISM XSLTs to render sample banner and portion marks.
