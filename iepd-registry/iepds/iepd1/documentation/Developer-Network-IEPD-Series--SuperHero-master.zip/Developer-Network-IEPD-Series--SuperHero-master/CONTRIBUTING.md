

The National Information Exchange Model (NIEM) Program GitHub page welcomes your comments and postings. Comments posted to the NIEM GitHub page are subject to GitHub’s usage, abuse, and comment policies at https://help.github.com/articles/github-terms-of-service/. Your comments are public and available to anyone visiting the NIEM GitHub page.

To protect your privacy and the privacy of others, do not include your full name, phone numbers, email addresses, social security number, case numbers or any other sensitive personally identifiable information (PII) in your comments or responses.

NIEM does not moderate comments on the NIEM GitHub page prior to posting, but reserves the right to remove any materials that pose a security or privacy risk.
