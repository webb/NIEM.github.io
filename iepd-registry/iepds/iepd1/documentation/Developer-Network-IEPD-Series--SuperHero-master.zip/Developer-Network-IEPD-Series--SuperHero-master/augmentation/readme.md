This NIEM v3.0 IEPD builds off the Super Hero Based IEPD demonstrates how to implement the augmentation concept in NIEM.  

The definition for "Augmentation" is provided in the Naming and Design Rules (NDR) specification in Section 10.4. Additional rules for "Augumentation" are provided in Section 6.5.5, and Section 10.4.4.

The definition for "Augmentable Type" is provided in the NDR Section 10.4.1.  Additional rules for "Augmentable Type are provide in Section 10.4.2.

The definition for "Augmentation Element Declaration" are provided in Section 10.4.4.  Additional rules for "Augmentation Element Declaration" are provided in Section 10.4.5.

The definition for "Augmentation Type is provided in Section 10.4.4.  Additioanl rules for "Augmetation Type" are provided in Section 5.6.5.6, and Section 5.6.5.7.

Quicklinks to these references are provided in Appendix G. General Index in the NDR at URL:  http://reference.niem.gov/niem/specification/naming-and-design-rules/3.0/NIEM-NDR-3.0-2014-07-31.html#appendix_G. 
