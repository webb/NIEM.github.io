This NIEM v3.0 IEPD builds off the Super Hero Based IEPD demonstrates how to implement specialization using they "type inheritance" in NIEM. 

This concept is discussed in the Naming and Design Rules in Section 6.5.5. Reserve inheritance for specialization.
 
Quicklinks to these references are provided in Appendix G. General Index in the NDR at URL:  http://reference.niem.gov/niem/specification/naming-and-design-rules/3.0/NIEM-NDR-3.0-2014-07-31.html#appendix_G. 